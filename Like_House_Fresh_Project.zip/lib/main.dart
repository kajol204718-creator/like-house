import 'package:flutter/material.dart';

void main() => runApp(const LikeHouseApp());

class LikeHouseApp extends StatefulWidget {
  const LikeHouseApp({super.key});
  @override
  State<LikeHouseApp> createState() => _LikeHouseAppState();
}

class _LikeHouseAppState extends State<LikeHouseApp> {
  bool english = false;
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1877F2)),
      scaffoldBackgroundColor: const Color(0xFFF4F7FC),
    ),
    home: LikeHome(english: english, onLanguage: (v) => setState(() => english = v)),
  );
}

class LikeHome extends StatefulWidget {
  final bool english;
  final ValueChanged<bool> onLanguage;
  const LikeHome({super.key, required this.english, required this.onLanguage});
  @override
  State<LikeHome> createState() => _LikeHomeState();
}

class _LikeHomeState extends State<LikeHome> {
  final link = TextEditingController();
  String? reaction;
  final items = const [
    ('Like', '👍'), ('Love', '❤️'), ('Care', '🤗'), ('Haha', '😂'),
    ('Wow', '😮'), ('Sad', '😢'), ('Angry', '😡'),
  ];
  String tr(String bn, String en) => widget.english ? en : bn;

  @override
  void dispose() { link.dispose(); super.dispose(); }

  void show(String message) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(message)));

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      backgroundColor: const Color(0xFF1877F2),
      foregroundColor: Colors.white,
      title: const Text('LIKE HOUSE', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1)),
      actions: [
        PopupMenuButton<bool>(
          onSelected: widget.onLanguage,
          itemBuilder: (_) => const [
            PopupMenuItem(value: false, child: Text('বাংলা')),
            PopupMenuItem(value: true, child: Text('English')),
          ],
          child: const Padding(
            padding: EdgeInsets.symmetric(horizontal: 14),
            child: Row(children: [Icon(Icons.language), SizedBox(width: 5), Text('BN / EN')]),
          ),
        )
      ],
    ),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(colors: [Color(0xFF1265D8), Color(0xFF63A5FF)]),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(tr('স্বাগতম Like House-এ!', 'Welcome to Like House!'),
              style: const TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(tr('শেয়ার করুন • যুক্ত থাকুন • রিঅ্যাক্ট করুন', 'Share • Connect • React'),
              style: const TextStyle(color: Colors.white)),
          ]),
        ),
        const SizedBox(height: 22),
        Text(tr('Facebook পোস্টের লিংক', 'Facebook post link'),
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
        const SizedBox(height: 9),
        TextField(
          controller: link,
          keyboardType: TextInputType.url,
          decoration: InputDecoration(
            hintText: 'https://www.facebook.com/...',
            prefixIcon: const Icon(Icons.link),
            filled: true, fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
          ),
        ),
        const SizedBox(height: 10),
        FilledButton.icon(
          onPressed: () {
            final value = link.text.trim();
            if (!(value.startsWith('https://') || value.startsWith('http://'))) {
              show(tr('সঠিক লিংক দিন।', 'Please enter a valid link.'));
            } else {
              show(tr('ডেমোতে লিংকটি গ্রহণ করা হয়েছে।', 'Link accepted in demo.'));
            }
          },
          icon: const Icon(Icons.add_link),
          label: Text(tr('পোস্ট জমা দিন', 'Submit post')),
        ),
        const SizedBox(height: 22),
        Text(tr('রিঅ্যাকশন বেছে নিন', 'Choose a reaction'),
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
        const SizedBox(height: 10),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: items.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 4, crossAxisSpacing: 9, mainAxisSpacing: 9, childAspectRatio: 1.05),
          itemBuilder: (_, i) {
            final item = items[i];
            final active = reaction == item.$1;
            return InkWell(
              borderRadius: BorderRadius.circular(15),
              onTap: () => setState(() => reaction = item.$1),
              child: Container(
                decoration: BoxDecoration(
                  color: active ? const Color(0xFFE0EDFF) : Colors.white,
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: active ? const Color(0xFF1877F2) : Colors.transparent, width: 2),
                ),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text(item.$2, style: const TextStyle(fontSize: 27)),
                  const SizedBox(height: 4),
                  Text(item.$1, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                ]),
              ),
            );
          },
        ),
        if (reaction != null) ...[
          const SizedBox(height: 12),
          Card(child: Padding(
            padding: const EdgeInsets.all(14),
            child: Text(tr('নির্বাচিত রিঅ্যাকশন: $reaction (শুধু ডেমো)',
              'Selected reaction: $reaction (demo only)')),
          )),
        ],
        const SizedBox(height: 18),
        Card(child: Padding(
          padding: const EdgeInsets.all(14),
          child: Text(tr(
            'এটি নতুন প্রাথমিক ডেমো। এখানে রিঅ্যাকশন নির্বাচন ও লিংক ইনপুট কাজ করে। Facebook-এ আসল রিঅ্যাকশন পাঠানো, লগইন, পোস্ট সংরক্ষণ ও অ্যাডমিন প্যানেলের জন্য নিরাপদ ব্যাকএন্ড এবং Meta-অনুমোদিত API/লগইন প্রয়োজন।',
            'This is a fresh starter demo. Link input and local reaction selection work. Real Facebook reactions, accounts, post storage and admin tools require a secure backend and Meta-approved API/login access.'
          ), style: const TextStyle(fontSize: 13)),
        )),
      ],
    ),
  );
}
