# Like House — fresh Android starter

This repository is a clean Flutter project with a bilingual Bangla/English demo UI.

## Included
- Bangla / English switch
- Facebook post URL input with basic URL validation
- Seven reaction choices (local demo selection)
- GitHub Actions workflow to build a release APK

## Important
This starter does not send reactions to Facebook. A public post URL alone cannot authorize reactions. Real Facebook integration requires Meta-approved permissions and a secure backend. Firebase Authentication and Firestore are not wired into this fresh starter yet; they need a Firebase app configuration and security rules before production use.

## Build
Push these files to GitHub, then open **Actions** and run **Build Like House APK**. Download `Like-House-APK` from the successful run's Artifacts section.
