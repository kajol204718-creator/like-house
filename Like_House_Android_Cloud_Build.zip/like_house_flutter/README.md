# Like House — Flutter starter

This is a bilingual (Bangla/English) Android starter/demo for Like House.

## Included
- Bangla / English language switch
- Facebook post-link input (demo validation only)
- Seven reaction choices (local UI selection only)
- Basic home screen styling

## Not included yet
- Real Facebook reactions or automated reactions
- User registration / authentication
- Backend database, moderation, admin panel
- Facebook login/API integration

Facebook does not allow an app to send arbitrary reactions merely from a public post URL. Any production integration must use Meta-approved permissions and comply with Meta Platform Terms and rate limits. Do not collect Facebook passwords or session cookies.

## Build APK
Install Flutter SDK and Android SDK, then run:
```bash
flutter pub get
flutter build apk --release
```
The APK will be created at:
`build/app/outputs/flutter-apk/app-release.apk`

This ZIP is source code, not a compiled APK.
