import 'package:flutter/material.dart';

void main() => runApp(const LikeHouseApp());

class LikeHouseApp extends StatefulWidget {
  const LikeHouseApp({super.key});
  @override
  State<LikeHouseApp> createState() => _LikeHouseAppState();
}

class _LikeHouseAppState extends State<LikeHouseApp> {
  bool english = false;
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1877F2)),
      useMaterial3: true,
      scaffoldBackgroundColor: const Color(0xFFF5F8FF),
    ),
    home: HomePage(
      english: english,
      onLanguageChanged: (v) => setState(() => english = v),
    ),
  );
}

class HomePage extends StatefulWidget {
  final bool english;
  final ValueChanged<bool> onLanguageChanged;
  const HomePage({super.key, required this.english, required this.onLanguageChanged});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final linkController = TextEditingController();
  String? selectedReaction;
  final reactions = [
    ('Like', '👍'), ('Love', '❤️'), ('Care', '🤗'),
    ('Haha', '😂'), ('Wow', '😮'), ('Sad', '😢'), ('Angry', '😡'),
  ];
  String t(String bn, String en) => widget.english ? en : bn;

  @override
  void dispose() {
    linkController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF1877F2),
        foregroundColor: Colors.white,
        title: const Row(children: [
          Icon(Icons.thumb_up_alt_rounded),
          SizedBox(width: 9),
          Text('LIKE HOUSE', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1)),
        ]),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: PopupMenuButton<bool>(
              tooltip: 'Language',
              onSelected: widget.onLanguageChanged,
              itemBuilder: (_) => const [
                PopupMenuItem(value: false, child: Text('বাংলা')),
                PopupMenuItem(value: true, child: Text('English')),
              ],
              child: const Row(children: [Icon(Icons.language), SizedBox(width: 4), Text('BN / EN')]),
            ),
          )
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF1877F2), Color(0xFF5AA0FF)]),
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t('স্বাগতম Like House-এ!', 'Welcome to Like House!'),
                style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 7),
              Text(t('শেয়ার করুন, যুক্ত থাকুন, রিঅ্যাকশন দিন।', 'Share, connect and react.'),
                style: const TextStyle(color: Colors.white, fontSize: 14)),
            ]),
          ),
          const SizedBox(height: 18),
          Text(t('Facebook পোস্টের লিংক', 'Facebook post link'),
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
          const SizedBox(height: 8),
          TextField(
            controller: linkController,
            keyboardType: TextInputType.url,
            decoration: InputDecoration(
              hintText: 'https://www.facebook.com/...',
              prefixIcon: const Icon(Icons.link),
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
            ),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: () {
              final value = linkController.text.trim();
              if (!value.startsWith('https://') && !value.startsWith('http://')) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(t('সঠিক পোস্ট লিংক দিন।', 'Please enter a valid post link.'))));
                return;
              }
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(t('ডেমো: লিংক গ্রহণ করা হয়েছে।', 'Demo: link received.'))));
            },
            icon: const Icon(Icons.add_link),
            label: Text(t('পোস্ট জমা দিন', 'Submit post')),
          ),
          const SizedBox(height: 22),
          Text(t('রিঅ্যাকশন বেছে নিন', 'Choose a reaction'),
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
          const SizedBox(height: 10),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: reactions.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4, childAspectRatio: 1.05, crossAxisSpacing: 9, mainAxisSpacing: 9),
            itemBuilder: (context, i) {
              final item = reactions[i];
              final active = selectedReaction == item.$1;
              return InkWell(
                borderRadius: BorderRadius.circular(15),
                onTap: () => setState(() => selectedReaction = item.$1),
                child: Container(
                  decoration: BoxDecoration(
                    color: active ? const Color(0xFFE2EEFF) : Colors.white,
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: active ? const Color(0xFF1877F2) : Colors.transparent, width: 2),
                  ),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text(item.$2, style: const TextStyle(fontSize: 27)),
                    const SizedBox(height: 4),
                    Text(item.$1, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                  ]),
                ),
              );
            },
          ),
          const SizedBox(height: 16),
          if (selectedReaction != null)
            Card(child: Padding(
              padding: const EdgeInsets.all(14),
              child: Text(t('আপনি ${selectedReaction!} বেছে নিয়েছেন। এটি এখন শুধু ডেমো নির্বাচন।',
                'You selected ${selectedReaction!}. This is a demo selection only.')),
            )),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Icon(Icons.info_outline, color: Color(0xFF1877F2)),
                const SizedBox(width: 10),
                Expanded(child: Text(t(
                  'এটি প্রাথমিক ডেমো। Facebook-এ আসল রিঅ্যাকশন পাঠানো, ইউজার অ্যাকাউন্ট, পোস্ট সংরক্ষণ ও অ্যাডমিন প্যানেলের জন্য নিরাপদ সার্ভার এবং Facebook-এর অনুমোদিত API/লগইন প্রয়োজন।',
                  'This is an initial demo. Real Facebook reactions, user accounts, post storage and an admin panel require a secure backend and Facebook-approved API/login access.'
                ), style: const TextStyle(fontSize: 13))),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}
